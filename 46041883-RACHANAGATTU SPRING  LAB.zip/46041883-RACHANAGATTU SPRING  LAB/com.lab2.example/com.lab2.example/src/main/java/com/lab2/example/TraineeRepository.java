package com.lab2.example;
import org.springframework.data.repository.CrudRepository;

public interface TraineeRepository extends CrudRepository<Trainee, Integer> {
}