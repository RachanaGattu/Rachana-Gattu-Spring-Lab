package com.lab2.example;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TranieeController {
 
	@Autowired
	TraineeService traineeService;


	@GetMapping("/Trainee")
	private List<Trainee> getAllTrainee() {
		return traineeService.getAllTrainee();
	}
	
	@GetMapping("/Trainee/{traineeName}")
	private List<Trainee> getTraineeByName(@PathVariable("traineeName") String traineeName) {
		return traineeService.getTraineeByName(traineeName);
	}
	
	@GetMapping("/Trainee/{traineeId}")
	private List<Trainee> getTrainee(@PathVariable("traineeId") int traineeId) {
		return traineeService.getTraineeById(traineeId);
	}

	@DeleteMapping("/Trainee/{traineeId}")
	private void deleteTrainee(@PathVariable("traineeId") int traineeId) {
		traineeService.delete(traineeId);
	}

	@PostMapping("/Trainee")
	private int saveTrainee(@RequestBody Trainee Trainee) {
		traineeService.saveOrUpdate(Trainee);
		return Trainee.getTraineeId();
	}

	@PutMapping("/Trainee")
	private Trainee update(@RequestBody Trainee Trainee) {
		traineeService.saveOrUpdate(Trainee);
		return Trainee;
	}
	
	
}