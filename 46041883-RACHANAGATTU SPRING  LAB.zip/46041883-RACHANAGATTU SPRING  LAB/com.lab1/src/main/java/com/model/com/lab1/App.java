package com.model.com.lab1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Start" );
        ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
        Employee employee = context.getBean("employee", Employee.class);
       System.out.println(employee.toString());
       SBU sbu = context.getBean("sbu", SBU.class);
       System.out.println(sbu.toString());
    }
}
